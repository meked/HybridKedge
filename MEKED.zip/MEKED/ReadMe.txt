To install: drop folder into desired location. 
The folder KED_TEMP\ must be in the same directory as MEKED.exe.
Making shortcuts to MEKED.exe will not break the code.
